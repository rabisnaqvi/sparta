<?php
/**
 * Code House
 *
 * @package     CodeHouse
 * @author      Code House
 * @copyright   2016 Cheers Bin Network
 *
 * @wordpress-plugin
 * Plugin Name: Code House
 * Plugin URI:  http://codehouse.services.cheersbin.com
 * Description: Official Code House Plugin for dealing with Code House Products.
 * Version:     1.0.0
 * Author:      Cheers Bin Network
 * Author URI:  https://cheersbin.com
 * Text Domain: code_house
 */

$theme = wp_get_theme();
global $theme;
if(!isset($theme)) {
    return;
}
require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
if($theme->get('Name') != 'Sparta Theme' && $theme->get('Name') != 'Sparta Child Theme') {
	deactivate_plugins( plugin_basename( __FILE__ ) );
    return;
}
// Add Custom Css For Admin Panel
if(class_exists('Redux')) {
function addPanelCSS() {
    wp_register_style(
        'codehouse_panelstyle',
        plugin_dir_url(__FILE__).'/assets/panel.css',
        array( 'redux-admin-css' ),
        time(),
        'all'
    );  
    wp_enqueue_style('codehouse_panelstyle');
}
add_action( 'redux/page/sparta/enqueue', 'addPanelCSS' );
}

// Add Admin Bar logo
function codehouse_custom_logo() {
echo '
<style type="text/css">
#wpadminbar #wp-admin-bar-wp-logo > .ab-item .ab-icon:before {
background-image: url(' . plugin_dir_url(__FILE__) . 'assets/icon.png) !important;
background-position: 0 0;
color:rgba(0, 0, 0, 0);
background-size: 21px;
background-repeat: no-repeat;
}
#wpadminbar #wp-admin-bar-wp-logo.hover > .ab-item .ab-icon {
background-position: 0 0;
}
#wpadminbar #wp-admin-bar-wp-logo .ab-sub-wrapper {
display: none !important;
}
.ab-sub-wrapper {

}
</style>
';
}

//hook into the administrative header output
add_action('wp_before_admin_bar_render', 'codehouse_custom_logo');



/**
 * Add a widget to the dashboard.
 *
 * This function is hooked into the 'wp_dashboard_setup' action below.
 */
function codehouse_add_dashboard_widgets() {
	global $theme;
	wp_add_dashboard_widget(
                 'codehouse',         // Widget slug.
                 'Thanks for creating it with '.$theme->get('Name'),         // Title.
                 'codehouse_dashboard_widget_function' // Display function.
        );	
}
add_action( 'wp_dashboard_setup', 'codehouse_add_dashboard_widgets' );

/**
 * Create the function to output the contents of our Dashboard Widget.
 */
function codehouse_dashboard_widget_function() {
	global $theme;
	// Display whatever it is you want to show.
	echo '<img src="'.$theme->get_screenshot().'" style="max-width: 100%; height: auto;"/>';
}
